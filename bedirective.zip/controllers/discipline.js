const disciplines = [
    { id: 1, discipline: "Basketball", abbreviation: "BB", gender: "Male" },
    { id: 2, discipline: "Volleyball", abbreviation: "VB", gender: "Female" },
];

const getDisciplines = (req, res) => {
    res.json(disciplines);
};

const createDiscipline = (req, res) => {
    const { discipline, abbreviation, gender } = req.body;
    const newDiscipline = {
        id: disciplines.length ? disciplines[disciplines.length - 1].id + 1 : 1,
        discipline,
        abbreviation,
        gender,
    };
    disciplines.push(newDiscipline);
    res.status(201).json(newDiscipline);
};

const updateDiscipline = (req, res) => {
    const { id } = req.params;
    const { discipline, abbreviation, gender } = req.body;
    const index = disciplines.findIndex((d) => d.id === parseInt(id));

    if (index !== -1) {
        disciplines[index] = { ...disciplines[index], discipline, abbreviation, gender };
        res.json(disciplines[index]);
    } else {
        res.status(404).json({ message: "Discipline not found" });
    }
};

const deleteDiscipline = (req, res) => {
    const { id } = req.params;
    const index = disciplines.findIndex((d) => d.id === parseInt(id));

    if (index !== -1) {
        const deleted = disciplines.splice(index, 1);
        res.json(deleted[0]);
    } else {
        res.status(404).json({ message: "Discipline not found" });
    }
};

module.exports = { getDisciplines, createDiscipline, updateDiscipline, deleteDiscipline };
